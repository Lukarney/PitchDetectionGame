from cmu_112_graphics import *
from tkinter import *
from PIL import Image
import random

class Bird(object):
    # class attribute
    isMigrating = False
    # take in one parameter name
    def __init__(self, name):
        self.name = name
        self.eggs = 0
    @staticmethod
    def startMigrating():
        Bird.isMigrating = True
    @staticmethod
    def stopMigrating():
        Bird.isMigrating = False
    def fly(self):
        return "I can fly!"
    def layEgg(self):
        self.eggs += 1
    def countEggs(self):
        return self.eggs
    def __repr__(self):
        if self.eggs == 1:
            return f'{self.name} has {self.eggs} egg'
        else: 
            return f'{self.name} has {self.eggs} eggs'
    def __hash__(self):
        return hash(self.name)
    def __eq__(self, other):
        return (isinstance(other, Bird) and (self.name == other.name))
class Penguin(Bird):
    # override superclass method
    def fly(self):
        return "No flying for me."
    def swim(self):
        return "I can swim!"
class MessengerBird(Bird):
    # inherit superclass properties and initiate new one
    def __init__(self,name,message):
        super().__init__(name)
        self.message = message
    def deliverMessage(self):
        return self.message

# ignore_rest (The autograder ignores all code below here)
def getLocalMethods(clss):
    import types
    # This is a helper function for the test function below.
    # It returns a sorted list of the names of the methods
    # defined in a class. It's okay if you don't fully understand it!
    result = [ ]
    for var in clss.__dict__:
        val = clss.__dict__[var]
        if (isinstance(val, types.FunctionType)):
            result.append(var)
    return sorted(result)

def testBirdClasses():
    print("Testing Bird classes...", end="")
    # A basic Bird has a species name, can fly, and can lay eggs
    bird1 = Bird("Parrot")
    assert(type(bird1) == Bird)
    assert(isinstance(bird1, Bird))
    assert(bird1.fly() == "I can fly!")
    assert(bird1.countEggs() == 0)
    assert(str(bird1) == "Parrot has 0 eggs")
    bird1.layEgg()
    assert(bird1.countEggs() == 1)
    assert(str(bird1) == "Parrot has 1 egg")
    bird1.layEgg()
    assert(bird1.countEggs() == 2)
    assert(str(bird1) == "Parrot has 2 eggs")
    tempBird = Bird("Parrot")
    assert(bird1 == tempBird)
    tempBird = Bird("Wren")
    assert(bird1 != tempBird)
    nest = set()
    assert(bird1 not in nest)
    assert(tempBird not in nest)
    nest.add(bird1)
    assert(bird1 in nest)
    assert(tempBird not in nest)
    nest.remove(bird1)
    assert(bird1 not in nest)
    assert(getLocalMethods(Bird) == ['__eq__','__hash__','__init__', 
                                     '__repr__', 'countEggs', 
                                     'fly', 'layEgg'])
    
    # A Penguin is a Bird that cannot fly, but can swim
    bird2 = Penguin("Emperor Penguin")
    assert(type(bird2) == Penguin)
    assert(isinstance(bird2, Penguin))
    assert(isinstance(bird2, Bird))
    assert(not isinstance(bird1, Penguin))
    assert(bird2.fly() == "No flying for me.")
    assert(bird2.swim() == "I can swim!")
    bird2.layEgg()
    assert(bird2.countEggs() == 1)
    assert(str(bird2) == "Emperor Penguin has 1 egg")
    assert(getLocalMethods(Penguin) == ['fly', 'swim'])
    
    # A MessengerBird is a Bird that carries a message
    bird3 = MessengerBird("War Pigeon", "Top-Secret Message!")
    assert(type(bird3) == MessengerBird)
    assert(isinstance(bird3, MessengerBird))
    assert(isinstance(bird3, Bird))
    assert(not isinstance(bird3, Penguin))
    assert(not isinstance(bird2, MessengerBird))
    assert(not isinstance(bird1, MessengerBird))
    assert(bird3.deliverMessage() == "Top-Secret Message!")
    assert(str(bird3) == "War Pigeon has 0 eggs")
    assert(bird3.fly() == "I can fly!")

    bird4 = MessengerBird("Homing Pigeon", "")
    assert(bird4.deliverMessage() == "")
    bird4.layEgg()
    assert(bird4.countEggs() == 1)
    assert(getLocalMethods(MessengerBird) == ['__init__', 'deliverMessage'])

    # Note: all birds are migrating or not (together, as one)
    assert(bird1.isMigrating == bird2.isMigrating == bird3.isMigrating == False)
    assert(Bird.isMigrating == False)

    bird1.startMigrating()
    assert(bird1.isMigrating == bird2.isMigrating == bird3.isMigrating == True)
    assert(Bird.isMigrating == True)

    Bird.stopMigrating()
    assert(bird1.isMigrating == bird2.isMigrating == bird3.isMigrating == False)
    assert(Bird.isMigrating == False)
    print("Done!")

def testAll():
    testBirdClasses()

def main():
    testAll()

if __name__ == '__main__':
    main()

# Player can consume ball
class Ball(object):
    def __init__(self,mode,cx,cy):
        self.mode = mode
        self.cx = cx
        self.cy = cy
        self.r = 10
    def collision(self):
        dx = self.mode.player.imageWidth/2
        dy = self.mode.player.imageHeight/2
        cx = self.cx - self.mode.scrollX
        cy = self.cy - self.mode.scrollY 
        if (self.mode.app.gameMode.player.x - dx) < cx < \
            (self.mode.app.gameMode.player.x + dx) and \
            (self.mode.app.gameMode.player.y - dy) < cy < \
            (self.mode.app.gameMode.player.y + dy):
            return True
    def getHashables(self):
        return (self.cx, self.cy)
    def __hash__(self):
        return hash(self.getHashables())
    def __eq__(self, other):
        return (isinstance(other, Ball) and (self.cx == other.cx) and (self.cy == other.cy))

# When consumed by player, player score +1
# inherit all properties from class Ball    
class EnergyBall(Ball): 
    # draw yellow energy ball
    def draw(self,canvas):
        cx = self.cx - self.mode.scrollX 
        cy = self.cy - self.mode.scrollY
        canvas.create_oval(cx + self.r, cy + self.r, cx - self.r, \
                            cy - self.r, fill = 'yellow')
# When consumed by player, score -1
# inherit all properties from class Ball
class Bomb(Ball): 
    # draw red bomb
    def draw(self,canvas):
        cx = self.cx - self.mode.scrollX
        cy = self.cy - self.mode.scrollY
        canvas.create_oval(cx + self.r, cy + self.r, cx - self.r, \
                            cy - self.r, fill = 'red')

# player always stays at one spot
class Player(object):
    # player starts off in the center of the screen and has score
    def __init__(self,mode):
        self.mode = mode
        self.score = 0
        self.x = self.mode.app.width/2
        self.y = self.mode.app.height/2
        # fire ball sprite animation
        url = 'https://i.imgur.com/5kz7uLg.png'
        spritestrip = mode.loadImage(url)
        self.sprites = [ ]
        for i in range(4):
            cropx = 150
            cropy = 150
            sprite = spritestrip.crop((cropx*i, 0, cropx*(i+1), cropy))
            scaleSprite = mode.scaleImage(sprite,1/3)
            self.sprites.append(scaleSprite)
        self.imageWidth, self.imageHeight = scaleSprite.size
        self.spriteCounter = 0
        self.timerDelay = 50
    # indexing through cropped images
    def timerFired(self):
        self.spriteCounter = (1 + self.spriteCounter) % len(self.sprites)
    # draw player animation
    def draw(self,canvas):
        sprite = self.sprites[self.spriteCounter]
        canvas.create_image(self.x, self.y, image=ImageTk.PhotoImage(sprite))

# enemy chases player
class Enemy(object):
    # start location random, load character's image 
    def __init__(self,mode):
        self.mode = mode
        self.x = random.randint(0,mode.app.width)
        self.y = random.randint(0,mode.app.height)
        url = 'https://i.imgur.com/lZM6eSY.jpg'
        self.image1 = self.mode.loadImage(url)
        self.image2 = self.mode.scaleImage(self.image1, 1/10)
    # moves in the direction of player
    # new location affected by scroll
    def timerFired(self):
        move = 7
        if self.x < self.mode.app.gameMode.player.x: dx = 5
        elif self.x > self.mode.app.gameMode.player.x:  dx = -5
        else: dx = 0
        self.x += dx - self.mode.signX * move
        if self.y < self.mode.app.gameMode.player.y: dy = 5
        elif self.y > self.mode.app.gameMode.player.y: dy = -5
        else: dy = 0
        self.y += dy - self.mode.signY * move
    # check if enemy collides with player
    def collision(self):
        dx = self.mode.player.imageWidth/2
        dy = self.mode.player.imageHeight/2
        if (self.mode.app.gameMode.player.x - dx) < self.x < \
            (self.mode.app.gameMode.player.x + dx) and \
            (self.mode.app.gameMode.player.y - dy) < self.y < \
            (self.mode.app.gameMode.player.y + dy):
            return True
    # draw enemy
    def draw(self,canvas):
        canvas.create_image(self.x,self.y,image=ImageTk.PhotoImage(self.image2))

# Start Menu
class SplashScreenMode(Mode):
    # draw Start Menu Instruction
    def redrawAll(mode, canvas): 
        text = 'Press Space to Start the Game'
        text2 = 'Press Enter to Read Instructions'
        font = 'Arial 20 bold'
        canvas.create_text(mode.app.width/2,mode.app.height/2,\
                            text=text,font=font)
        canvas.create_text(mode.app.width/2,mode.app.height/2+50,\
                            text=text2,font=font)
    # press key to go to different modes
    def keyPressed(mode, event):
        if event.key == "Space":
            mode.app.setActiveMode(mode.app.gameMode)
        elif event.key == "Enter":
            mode.app.setActiveMode(mode.app.helpMode)
# actual gaming
class GameMode(Mode):
    # set up game state
    def appStarted(mode):
        mode.player = Player(mode)
        mode.enemy = Enemy(mode)
        mode.scrollX = 0
        mode.scrollY = 0
        mode.signX = 0
        mode.signY = 0
        mode.energyBall = set()
        mode.bomb = set()
        # randomly create 100 instances of energy balls in a set
        for _ in range (100):
            x = random.randrange(1000)
            y = random.randrange(1000)
            # every energy ball has its unique location 
            if EnergyBall(mode, x, y) not in mode.energyBall:
                mode.energyBall.add(EnergyBall(mode, x, y))
        # randomly create 100 instances of bombs in a set
        for _ in range (100):
            x = random.randrange(1000)
            y = random.randrange(1000)
            # every bomb has its unique location 
            if Bomb(mode, x, y) not in mode.bomb:
                mode.bomb.add(Bomb(mode, x, y))
        mode.gameOver = False
        # create a custom cursor image
        url = 'https://i.imgur.com/H1mtK0F.jpg'
        mode.cursorImage = mode.loadImage(url)
        mode.cursorImage2 = mode.scaleImage(mode.cursorImage,1/25)
        mode.cursorX = -1
        mode.cursorY = -1
        mode.movePlayer = False
    # if mouse pressed on the player, enable to move player
    def mousePressed(mode,event):
        if mode.player.x - mode.player.imageWidth/2 < event.x < \
            mode.player.x + mode.player.imageWidth/2 \
            and mode.player.y - mode.player.imageHeight/2 < event.y < \
            mode.player.y + mode.player.imageHeight/2:
            mode.movePlayer = True
    # if player can be moved, player follows the mouse 
    def mouseDragged(mode,event):
        if mode.movePlayer:
            mode.player.x = event.x
            mode.player.y = event.y
    # when mouse released, player can't be moved
    def mouseReleased(mode,event):
        if mode.movePlayer:
            mode.movePlayer = False
    # use mouse location relative to player location 
    # to determine which direction player moves
    def mouseMoved(mode, event):
        mode.cursorX = event.x
        mode.cursorY = event.y
        if (event.x > mode.player.x):    mode.signX = +1
        elif (event.x < mode.player.x):     mode.signX = -1
        else: mode.signY = 0
        if (event.y > mode.player.y):    mode.signY = +1
        elif (event.y < mode.player.y):    mode.signY = -1
        else: mode.signY = 0
    # sidescrolling: update scrollX and scrollY
    def timerFired(mode):
        # check if gameover
        if mode.enemy.collision() or mode.player.score == 20:
            mode.app.setActiveMode(mode.app.gameOverMode)
        mode.player.timerFired()
        move = 5
        mode.scrollX += mode.signX * move
        mode.scrollY += mode.signY * move
        mode.enemy.timerFired()
        # remove ball when eaten
        energyBallToKeep = []
        for energyBall in mode.energyBall:
            if not energyBall.collision():
                energyBallToKeep.append(energyBall)
            else:
                mode.player.score += 1
        mode.energyBall = energyBallToKeep
        bombToKeep = []
        for bomb in mode.bomb:
            if not bomb.collision():
                bombToKeep.append(bomb)
            else:
                mode.player.score -= 1
        mode.bomb = bombToKeep
    # draw energyBall, bomb, player, enemy, score, and cursor
    def redrawAll(mode, canvas):
        for energyBall in mode.energyBall: 
            energyBall.draw(canvas)
        for bomb in mode.bomb:
            bomb.draw(canvas)
        # draw cursor
        canvas.create_image(mode.cursorX,mode.cursorY,
                            image=ImageTk.PhotoImage(mode.cursorImage2))
        mode.player.draw(canvas)
        # draw score
        canvas.create_text(mode.player.x, mode.player.x, 
                            text=str(mode.player.score))
        mode.enemy.draw(canvas)

# Give Gameover Message and Score
class GameOverMode(Mode):
    def redrawAll(mode, canvas):
        text = f'Game Over! Your Score: {mode.app.gameMode.player.score}'
        font = 'Arial 20 bold'
        canvas.create_text(mode.app.width/2,mode.app.height/2,text=text,
                            font=font)
# Give Instructions
class HelpMode(Mode):
    def redrawAll(mode, canvas):
        font = 'Arial 15 bold'
        text = 'Press Any Key to Start The Game'
        text1 = 'Eat Yellow Dot: Score + 1, Eat Red Dot: Score - 1'
        text2 = 'Run into Water Ball: GameOver'
        text3 = 'Move Mouse to Control Direction'
        text4 = 'You Always Stay in the Center'
        text5 = 'Unless You Drag Yourself Elsewhere'
        text6 = 'Score 20 to Win'
        canvas.create_text(mode.app.width/2,100,text=text,font=font)
        canvas.create_text(mode.app.width/2,200,text=text1,font=font)
        canvas.create_text(mode.app.width/2,250,text=text2,font=font)
        canvas.create_text(mode.app.width/2,300,text=text3,font=font)
        canvas.create_text(mode.app.width/2,350,text=text4,font=font)
        canvas.create_text(mode.app.width/2,400,text=text5,font=font)
        canvas.create_text(mode.app.width/2,450,text=text6,font=font)
    def keyPressed(mode, event):
        mode.app.setActiveMode(mode.app.gameMode)

# top level class calls GameMode, HelpMode, GameOverMode,and SplashScreenMode
class MyModalApp(ModalApp):
    def appStarted(app):
        app.splashScreenMode = SplashScreenMode()
        app.gameMode = GameMode()
        app.helpMode = HelpMode()
        app.gameOverMode = GameOverMode()
        app.setActiveMode(app.splashScreenMode)
        app.timerDelay = 50

# Function that calls MyModalApp to run the game
def runCreativeSidescroller():
    MyModalApp(width=500,height=500)

runCreativeSidescroller()

